import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_polyline_points/flutter_polyline_points.dart';

import '../../state/route_selected_state.dart';
import '../../models/stop_model.dart';

class MapSection extends StatefulWidget {
  const MapSection({super.key});

  @override
  State<MapSection> createState() => _MapSectionState();
}

class _MapSectionState extends State<MapSection> {
  GoogleMapController? _mapController;

  LatLng _initialPosition = const LatLng(7.1193, -73.1227);
  bool _loading = true;

  Set<Polyline> polylines = {};
  List<StopModel> _lastStops = [];

  // 🔥 PON TU API KEY REAL
  final String _apiKey = "AIzaSyDJoLRVvxZqlbTQy0z8GmdYst234WGTwRc";

  @override
  void initState() {
    super.initState();
    _initLocation();
  }

  Future<void> _initLocation() async {
    LocationPermission permission = await Geolocator.requestPermission();

    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      setState(() => _loading = false);
      return;
    }

    final position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    if (!mounted) return;

    setState(() {
      _initialPosition = LatLng(position.latitude, position.longitude);
      _loading = false;
    });
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
  }

  /// 🔥 GOOGLE DIRECTIONS
  Future<List<LatLng>> _getRoute({
    required StopModel origin,
    required StopModel destination,
    List<StopModel> waypoints = const [],
  }) async {
    final uri = Uri.parse(
      "https://maps.googleapis.com/maps/api/directions/json"
      "?origin=${origin.latitude},${origin.longitude}"
      "&destination=${destination.latitude},${destination.longitude}"
      "&mode=driving"
      "&waypoints=${waypoints.map((e) => "${e.latitude},${e.longitude}").join("|")}"
      "&key=$_apiKey",
    );

    final response = await http.get(uri);
    final data = jsonDecode(response.body);

    print("STATUS: ${data["status"]}");

    if (data["status"] != "OK") return [];

    final encoded = data["routes"][0]["overview_polyline"]["points"];

    final decoded = PolylinePoints().decodePolyline(encoded);

    return decoded
        .map((e) => LatLng(e.latitude, e.longitude))
        .toList();
  }

  /// 🔥 IDA + REGRESO
  Future<void> _buildRoute(List<StopModel> stops) async {
    if (stops.length < 2) return;

    final ida = await _getRoute(
      origin: stops.first,
      destination: stops.last,
      waypoints: stops.length > 2
          ? stops.sublist(1, stops.length - 1)
          : [],
    );

    final regresoStops = stops.reversed.toList();

    final regreso = await _getRoute(
      origin: regresoStops.first,
      destination: regresoStops.last,
      waypoints: regresoStops.length > 2
          ? regresoStops.sublist(1, regresoStops.length - 1)
          : [],
    );

    if (!mounted) return;

    if (ida.isEmpty && regreso.isEmpty) {
      print("❌ SIN RUTA");
      return;
    }

    setState(() {
      polylines = {
        if (ida.isNotEmpty)
          Polyline(
            polylineId: const PolylineId("ida"),
            color: Colors.blue,
            width: 5,
            points: ida,
          ),
        if (regreso.isNotEmpty)
          Polyline(
            polylineId: const PolylineId("regreso"),
            color: Colors.blue,
            width: 5,
            points: regreso,
          ),
      };
    });

    _fitRoute([...ida, ...regreso]);
  }

  void _fitRoute(List<LatLng> points) {
    if (_mapController == null || points.isEmpty) return;

    double minLat = points.first.latitude;
    double maxLat = points.first.latitude;
    double minLng = points.first.longitude;
    double maxLng = points.first.longitude;

    for (final p in points) {
      if (p.latitude < minLat) minLat = p.latitude;
      if (p.latitude > maxLat) maxLat = p.latitude;
      if (p.longitude < minLng) minLng = p.longitude;
      if (p.longitude > maxLng) maxLng = p.longitude;
    }

    _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(
        LatLngBounds(
          southwest: LatLng(minLat, minLng),
          northeast: LatLng(maxLat, maxLng),
        ),
        60,
      ),
    );
  }

  bool _routeChanged(List<StopModel> stops) {
    if (_lastStops.isEmpty) return true;
    if (stops.length != _lastStops.length) return true;
    if (stops.first.id != _lastStops.first.id) return true;
    if (stops.last.id != _lastStops.last.id) return true;
    return false;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    return ValueListenableBuilder<List<StopModel>>(
      valueListenable: RouteSelectedState.stopsNotifier,
      builder: (context, stops, _) {

        if (stops.isEmpty && polylines.isNotEmpty) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            setState(() {
              polylines = {};
              _lastStops = [];
            });
          });
        }

        if (stops.isNotEmpty && _routeChanged(stops)) {
          _lastStops = List.from(stops);

          WidgetsBinding.instance.addPostFrameCallback((_) {
            _buildRoute(stops);
          });
        }

        return GoogleMap(
          initialCameraPosition: CameraPosition(
            target: _initialPosition,
            zoom: 14,
          ),
          onMapCreated: _onMapCreated,
          myLocationEnabled: true,
          myLocationButtonEnabled: true,
          zoomControlsEnabled: false,
          polylines: polylines,
        );
      },
    );
  }
}